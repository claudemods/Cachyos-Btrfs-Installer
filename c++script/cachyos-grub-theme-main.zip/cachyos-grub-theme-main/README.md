# Grub2 Theme CachyOS
##### AUTHOR: diegons490

#### After downloading the files, open the terminal in the folder where they are and run the command to install or uninstall the theme.
#### After installation the theme will be set automatically


#### Install theme:
```bash
sudo bash setup.sh
```

# Screenshot
![screenshot](/preview.png?raw=true)
